package RestAssured;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.testng.annotations.Test;

import com.google.gson.Gson;

import Constants.postUrls;
import POJO.userCrdentials;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostAPI {

	userCrdentials userPojo;

	@Test
	public void getPost() throws IOException {

		RestAssured.baseURI = postUrls.postUser + "/authenticate";
		RequestSpecification request = RestAssured.given();
		request.contentType("application/json");
		userPojo = new userCrdentials();

		userPojo.setUserName("rupeek");
		userPojo.setPassword("password");

		Gson gson = new Gson();
		String json = gson.toJson(userPojo);

		System.out.println("Request Payload==> " + json);
		request.body(userPojo);
		Response response = request.post();

		System.out.println("Status code: " + response.getStatusCode());
		System.out.println("message: " + response.asString());

		JsonPath pathh = response.jsonPath();
		String token = pathh.get("token");

		System.out.println("Generated Token--> " + token);
		userPojo.setToken(token);
		assertEquals(response.getStatusCode(), 200, "Verify the user does have permission to see the application");

		// Get api with user

		RequestSpecification requestUser = RestAssured.given();
		requestUser.contentType("application/json");
		requestUser.header("Authorization", "Bearer " + token);
		Response responseUser = requestUser.get("http://13.126.80.194:8080/api/v1/users");
		System.out.println("Code:--> " + responseUser.getStatusCode());

		JsonPath pathPhone = responseUser.jsonPath();
		String phoneStr = " " + pathPhone.get("phone");
		System.out.println(phoneStr.length());
		String split = phoneStr.substring(1, phoneStr.length() - 1);
		String[] arrayPhone = split.split(",");
		System.out.println("Phone-> " + arrayPhone[0]);

		System.out.println("User Response Body: " + responseUser.getBody().asString());

		assertEquals(responseUser.getStatusCode(), 200, "Verify the user does have the application data");

		RequestSpecification requestPhone = RestAssured.given();
		requestPhone.contentType("application/json");
		requestPhone.header("Authorization", "Bearer " + token);
		Response responsePhone = requestUser.get("http://13.126.80.194:8080/api/v1/users/phone");
		System.out.println("Code:--> " + responsePhone.getStatusCode());

		JsonPath pathPhoneNum = responseUser.jsonPath();
		String phoneResult = " " + pathPhoneNum.get("phone");
		System.out.println("phoneResult-->" + phoneResult);

		System.out.println("Individual User Response Body: " + responsePhone.getBody().asString());

		assertEquals(responsePhone.getStatusCode(), 200, "Verify the user phone");

	}
}
