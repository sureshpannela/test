package RestAssured;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import Constants.postUrls;
import POJO.userCrdentials;
import io.restassured.RestAssured;
import io.restassured.internal.RestAssuredResponseImpl;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAPI {

	userCrdentials userPojo;
	@Test(priority = 1)
	public void searchWithUser() {
		 
		RequestSpecification requestUser = RestAssured.given();
		System.out.println("Pojo:  "+userPojo.getToken());
		requestUser.contentType("application/json").header("Authorization", "bearer "+userPojo.getToken());
		RestAssured restApi = new RestAssured();
		Response response = restApi.get("http://13.126.80.194:8080/api/v1/users");
		
		int statusCode = response.getStatusCode();
		System.out.println(statusCode+" - "+response.asString());
		assertEquals(response.getStatusCode(),"200","Verify the status code of the user");
		
		
		
	}
//	@Test(priority = 2)
//	public void searchWithPhoneNumber() {
//		 
//		RestAssured restApi = new RestAssured();
//		Response response = restApi.get("");
//		int statusCode = response.getStatusCode();
//		System.out.println(statusCode+" - "+response.asString());
//		assertEquals(response.getStatusCode(),"200","Verify the status code with phone number");
//	}
}
