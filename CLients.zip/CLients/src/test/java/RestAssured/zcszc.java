package RestAssured;

public class zcszc {
public static void main(String[] args) {
	String s = "[8037602400, 9972939567, 9995879555]";
	String ds = s.substring(1,s.length()-1).trim();
	String[] dss = ds.split(",");
	System.out.println(dss[0]);
}
}
