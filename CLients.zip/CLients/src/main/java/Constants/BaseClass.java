package Constants;


public class BaseClass {

	public void setUpURL() {
		
	}
}
