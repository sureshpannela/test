package Constants;

public interface postUrls {

	public String postUser = "http://13.126.80.194:8080";
	
}
