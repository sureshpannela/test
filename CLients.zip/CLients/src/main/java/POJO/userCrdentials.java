package POJO;

public class userCrdentials {

	String username;
	String password;
	String token;
	public String getUserName() {
		return username;
	}
	public void setUserName(String userName) {
		this.username = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	@Override
	public String toString() {
		return "userCrdentials [username=" + username + ", password=" + password + ", token=" + token + "]";
	}
	
	
	
}
